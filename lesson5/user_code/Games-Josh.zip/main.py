
guide = open("guide.txt",'r')
menu = open("menu.txt",'r')
load = open("save.txt",'r')

# Open the guide
print(guide.read())

guide.close()

# Open the menu
print(menu.read())
choice = input()

menu.close()

isMenuDone = False
isEventDone = False
# Menu options
while isMenuDone == False:
    
    if(choice == "l"):
    
        startEventNumber = int(load.readline())
        isMenuDone = True
    
    elif(choice == "s"):
    
        startEventNumber = 1
        isMenuDone = True
    
    elif(choice == "e"):
    
        isMenuDone = True
        isEventDone = True
        
    else:
        print("Not an option")
        choice = input()

eventNumber = startEventNumber
while isEventDone == False:
    # Print dialogue and get a response from the user
    try:
        dialogue = open(str(eventNumber) + "_dialogue.txt", 'r')
        print(dialogue.read())
    except FileNotFoundError:
        print("No more events, guess you won.")
        isEventDone = True
        break
    
    options = [1,2,3,4,5,6,7]
    isOptionDone1 = False
    user_input = 0
    while isOptionDone1 == False:
        print("Option must be 1,2,3,4,5,6 or 7")
        user_input = input()
        for index in options:
            try:
                if int(user_input) == index:
                    isOptionDone1 = True
            except ValueError:
                    print("Not an option")
                    
    if user_input == "6":
        print("Saved at event number: " + str(eventNumber))
        load.close()
        load = open("save.txt",'w')
        load.write(str(eventNumber))
        load.close()
        print("Saved!")
        continue
        
    if user_input == "7":
        print("Do you really wish to exit? (Press y to exit)")
        if input() == "y":
            print("Goodbye")
            break
        else:
            print(dialogue.read())
                
    # Respond to the user's input, by either saving, killing the user, exciting,
    # displaying dialogue or continuing to the next scene
    try:
        option_response = open(str(eventNumber)+"_" +user_input+"_response.txt",'r')
        read_response = option_response.readlines()
    except FileNotFoundError:
        pass
    
    if read_response[0] == 'Dies\n':
            for line in read_response:
                if line != read_response[0]:
                    print(line)
            print("You died")
            isOptionDone2 = False
            while isOptionDone2 == False:
                print("Press L to load last save, E to exit or S to start again")
                i = input()
                if i == "L":
                    eventNumber = int(load.read())
                    option_response.close()
                    isOptionDone2 = True
                if i == "E":
                    print("Goodbye")
                    option_response.close()
                    isEventDone = True
                    break
                if i == "S":
                    eventNumber = 1
                    option_response.close()
                    isOptionDone2 = True
                else:
                    print("Not an option")
                
    if read_response[0] == "Finish Event\n":
            for line in read_response:
                if line != read_response[0]:
                    print(line)
            option_response.close()
            eventNumber = eventNumber + 1
            
    else:
        for lines in read_response:
            print(lines)
            